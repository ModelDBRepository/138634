%==================================AE===========
% intact
axis([0 3 0 0.4])
hold on
stem([0.11 0.32])
ylabel('CR','fontsize',14,'fontweight','b')
title('Acquired Equivalence: Phase 3 ','fontsize',14,'fontweight','b');

% Lesioned
axis([0 3 0 0.4])
hold on
stem([0.11 0.12])
ylabel('CR','fontsize',14,'fontweight','b')
title('Acquired Equivalence in the PHR-lesioned model ','fontsize',12,'fontweight','b');

%==================================ctx shift===========
% intact
axis([0 3 0 0.7])
hold on
stem([0.62 0.41])
ylabel('CR','fontsize',14,'fontweight','b')
title('Context Shift ','fontsize',14,'fontweight','b');

% intact extended training
axis([0 3 0 0.9])
hold on
stem([0.82 0.83])
ylabel('CR','fontsize',14,'fontweight','b')
title('Context Shift ','fontsize',14,'fontweight','b');


% lesioned
axis([0 3 0 0.7])
hold on
stem([0.57 0.57])
ylabel('CR','fontsize',14,'fontweight','b')
title('Context Shift ','fontsize',14,'fontweight','b');


%================================== LI ctx shift===========
% intact
axis([0 3 0 0.75])
hold on
stem([0.31 0.69])
ylabel('CR','fontsize',14,'fontweight','b')
title('LI Context Shift ','fontsize',14,'fontweight','b');

