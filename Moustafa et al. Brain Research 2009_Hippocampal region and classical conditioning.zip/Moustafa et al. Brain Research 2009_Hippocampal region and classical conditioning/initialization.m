% add activation vectors.***
% later add HC and Ach. ********
% Act is activation.. Resp is for response node.
% EC_MTl wts might be added as a scaling factor.
%*may need to put all to zero after finishing a trial
% there is some way for naming files from variables.
% shall I have thresholds for sig here
%==================================================================================
experiment_type = 'A+';
%experiment_type = 'A-'; % US does not appear..same number of time steps as in A+
%experiment_type = 'SP'; % Sensory preconditioning..3 phases.
%experiment_type = 'LI'; % latent inhibition..2 phases.

%experiment_type = 'LrIr'; % learned irrelevance..2 phases.
%experiment_type = 'LrIr2'; % I did that to compare LIRR to LI.
%experiment_type = 'LI_CtxShft';
%experiment_type = 'CtxShft';

%experiment_type = 'AE'; % Acquired equivalence. here, I simulate a task simpler than and similar to that of Courteau et al. (2002). the task: phase 1: AX-, YA-  (X and Y are contexts; unlike terms used in Courteau); phase 2: X+; Phase 3: Y-
%experiment_type = 'AE_withZ';
%experiment_type = 'EzHrd';
%experiment_type = 'Discrm';  % this is to see if the model can discrimnate between similar inputs..to be used as control for EzHrd
%experiment_type = 'Gen';   % this is for stimulus generalization
%experiment_type = 'Blking';  %blocking
%experiment_type = 'CP';  % compound preconditioning. 
%experiment_type = 'Rev';  % Reversal 
%experiment_type = 'Rev_B-';  % Reversal 
%experiment_type = 'Rev_A+';  % extinction
% do Ach
%experiment_type = 'NegPat';  % 
%experiment_type = 'NegPatExtra';  % 
%experiment_type = 'PosPat';  % positive patterning
%experiment_type = 'A+Extra';  % I added here another phase which is A-.. so this is really like extinction. I am doing it to show how 

% Choose
%experiment_type = 'OS'; % Over-shadowing...2 phases. control here is comparing B+ alone to exp condi
%experiment_type = 'OS2'; % Over-shadowing...2 phases. control here is comparing A+ to B+


if(ismember(experiment_type,['A+' 'A-' 'Discrm' 'NegPat' 'PosPat']))
    NumPhases = 1;
elseif(ismember(experiment_type,['SP' 'AE' 'AE_withZ' 'Blking']))
    NumPhases = 3;   % 3rd phase is testing and will be done later
elseif(ismember(experiment_type,['LI' 'LrIr' 'OS' 'OS2' 'LrIr2' 'CtxShft' 'LI_CtxShft' 'EzHrd' 'Gen' 'CP' 'Rev' 'Rev_A+' 'Rev_B-' 'A+Extra' 'NegPatExtra']))
    NumPhases = 2;
end

%==============================Network variables===========================
% this is the Cort-EC network. learning here is Hebb and WTA in EC
%NumCortNodes = 5; % this is the input . 5 is for 3 for ctx,cue A, and one US. The US might be changed. [ctx ctx ctx A US]
% NumCortNodes = 6; % this is the input . 5 is for 3 for ctx,cue A, Cue B, and one US. The US might be changed. [ctx ctx ctx A US]
NumCortNodes = 40; % this is the input. 16 for contexts X and Y, 16 for CSs A and B, 8 for US. *does it matter for ctx to have more units?

Cort_act= zeros (1,NumCortNodes);  % this is for activation values.

%US_index = NumCortNodes;  % I use this when I refer to the presence or absence of US. I chose to make the last unit representing US.
US_index = NumCortNodes;  % I use this when I refer to the presence or absence of US. I chose to make the last unit representing US.

% NumECNodes = 3; % EC serves compression and sims will investigate if it does differentiation as well. Hopefully yes. Ach might add noise.
NumNodesECPatch = 20; % EC serves compression and sims will investigate if it does differentiation as well. Hopefully yes.% this is now the num of nodes in each patch
%NumNodesECPatch = 5;  % Mar 26
NumECPatches = 10;
%NumECPatches = 30;  % Mar 26

NumECNodes = NumNodesECPatch * NumECPatches;
EC_act= zeros(NumECPatches, NumNodesECPatch);

%CortECWts = zeros(NumCortNodes,NumECNodes); % I might make it zeros or rand
CortECWts = rand(NumCortNodes,NumNodesECPatch,NumECPatches)/2; % I might make it zeros or rand.. 20 was 5.
CortECWts = rand(NumCortNodes,NumNodesECPatch,NumECPatches)/2.5; % I might make it zeros or rand.. 20 was 5.

% Apr 2

if(isequal(experiment_type,'CtxShft'))  % that works for both AE and Ctx Shift.. I think this is even better for AE
  %  CortECWts = rand(NumCortNodes,NumNodesECPatch,NumECPatches)/8.5; % I might make it zeros or rand.. 20 was 5.
end

% this is for the other network.
MTL_act =zeros(NumECPatches, NumNodesECPatch);  % info is relayed from EC to this vector. this was cerbellum in GM93.
Resp_act = zeros(1,1); % it is only one node.we here assume that this node is for CR and UR.

%MTLRespWts = zeros(1, NumNodesECPatch*NumECPatches); % this connects MTL to Response node. I might make it zeros.. Num MTL nodes does not have to be as EC
MTLRespWts = rand(NumECPatches, NumNodesECPatch)/2; % this connects MTL to Response node. I might make it zeros.. Num MTL nodes does not have to be as EC
MTLRespWts = rand(NumECPatches, NumNodesECPatch)/2.5; % this connects MTL to Response node. I might make it zeros.. Num MTL nodes does not have to be as EC


%****************** used to compare LI to LIRR
% if(isequal(experiment_type,'LI'))
%     load wts.mat   %to be removed
% end

%========================================= training variables=====

NumTmeSteps = 4;  %ordering is [ctx ctx ctxA ctx ctx ctxAUS];  % same in all sims I think..remember that GM93 only used ctx and ctxAUS iteration but my adding may not do much. old
%ordering is [ctx ctx ctxAUS ctxAUS];

% these are related to classical conditioning sims: A+ and A-
% these indicate which cues are presented at which subtrials
% when I just say ctx..this is the default which is ctx X

CtxX_subtrl = [1 2];
CtxY_subtrl = [1 2];

CtxXA_subtrl = [3 4];     % this is for A-
CtxXB_subtrl = [3 4];     % this has all indices of ctx cue subtrl

CtxXAUS_subtrl = [3 4];   % for A+
CtxYAUS_subtrl = [3 4];

CtxXAB_subtrl = [3 4];     % for SP
CtxYA_subtrl = [3 4];   % added for AE.. Mar 23
CtxXUS_subtrl = [3 4];
CtxYnoUS_subtrl = [3 4];

NumTrls = zeros(1, NumPhases);
if(isequal(experiment_type,'A+') | isequal(experiment_type,'A-'))
    NumTrls (1,1) = 100;
elseif(isequal(experiment_type,'SP'))
    if (extend_training == 0)
        NumTrls (1,1) = 50;
        NumTrls (1,2) = 100;
        NumTrls (1,3) = 50;
    else
        % extended training
        NumTrls (1,1) = 150;
        NumTrls (1,2) = 100;
        NumTrls (1,3) = 50;
    end
elseif(isequal(experiment_type,'LI'))   % manipulate number of trials
    if (extend_training == 0)
        
        NumTrls (1,1) = 50;
        NumTrls (1,2) = 50;
    else
        % extended training
        NumTrls (1,1) = 50;
        NumTrls (1,2) = 50;
    end
elseif (isequal(experiment_type,'LrIr') | isequal(experiment_type,'LrIr2'))
    NumTrls (1,1) = 100;  % was 50
    NumTrls (1,2) = 50;
elseif(isequal(experiment_type,'LI_CtxShft'))  % manipulate number of trials
    NumTrls (1,1) = 25;
    NumTrls (1,2) = 50;
elseif(isequal(experiment_type,'CtxShft'))
    if (extend_training == 0)
        NumTrls (1,1) = 5;
        NumTrls (1,2) = 5;
    else
        %extended training
        NumTrls (1,1) = 50;
        NumTrls (1,2) = 5;
    end
% elseif(isequal(experiment_type,'AE'))   % not used any more
%     NumTrls (1,1) = 50;
%     NumTrls (1,2) = 200;
%     NumTrls (1,3) = 50;
elseif(isequal(experiment_type,'AE_withZ'))
    NumTrls (1,1) = 200;
    NumTrls (1,2) = 400;
    NumTrls (1,3) = 100;
    
    %         NumTrls (1,1) = 300;
    %         NumTrls (1,2) = 100;
    %         NumTrls (1,3) = 100;
elseif(isequal(experiment_type,'EzHrd'))
    if (extend_training == 0)
        
        NumTrls (1,1) = 100;
        NumTrls (1,2) = 50;
    else
        NumTrls (1,1) = 300;
        NumTrls (1,2) = 50;
    end    
elseif(isequal(experiment_type,'Discrm'))
    NumTrls (1,1) = 100;
elseif(isequal(experiment_type,'Gen'))
    NumTrls (1,1) = 100;
    NumTrls (1,2) = 1;   % phase 2 is only for testing here
elseif(isequal(experiment_type,'Blking'))
    if (extend_training == 0)
        NumTrls (1,1) = 50;
        NumTrls (1,2) = 10;  % was 30
        NumTrls (1,3) = 50;
    else
        NumTrls (1,1) = 0;
        NumTrls (1,2) = 180;
        NumTrls (1,3) = 50;
    end  
elseif(isequal(experiment_type,'OS'))  % Overshadowing
    if (extend_training == 0)
        NumTrls (1,1) = 10;
        NumTrls (1,2) = 10;  % was 30
    else
        NumTrls (1,1) = 50;
        NumTrls (1,2) = 10;
    end 
elseif(isequal(experiment_type,'OS2'))  % Overshadowing
    if (extend_training == 0)
        NumTrls (1,1) = 5;
        NumTrls (1,2) = 24;  % mix of A+ and B+
    else
        NumTrls (1,1) = 50;
        NumTrls (1,2) = 24;
    end 
elseif(isequal(experiment_type,'CP'))
    NumTrls (1,1) = 0;
    NumTrls (1,2) = 400;   % phase 2 is only for testing here
elseif(isequal(experiment_type,'Rev'))
    NumTrls (1,1) = 100;
    NumTrls (1,2) = 100;   % phase 2 is only for testing here
elseif(isequal(experiment_type,'Rev_A+'))  % extinction
    NumTrls (1,1) = 10;
    NumTrls (1,2) = 50;   % phase 2 is only for testing here
elseif(isequal(experiment_type,'Rev_B-'))
    NumTrls (1,1) = 100;
    NumTrls (1,2) = 100;   % phase 2 is only for testing here
elseif(isequal(experiment_type,'NegPat'))
    NumTrls (1,1) = 200;
elseif(isequal(experiment_type,'NegPatExtra'))
    NumTrls (1,1) = 200;
    NumTrls (1,2) = 20;
elseif(isequal(experiment_type,'PosPat'))
    NumTrls (1,1) = 200;
elseif(isequal(experiment_type,'A+Extra'))
    NumTrls (1,1) = 100;
    NumTrls (1,2) = 10;   

end

NumTotalTrls = 0;
for i = 1:NumPhases
    NumTotalTrls = NumTotalTrls + NumTrls(1,i);
end

Resp_alltrls = zeros(NumTotalTrls, NumTmeSteps);  % this is just to save CR at each time step on every trial in all trials.

TrlNumTotal = 1;


% added Feb. 7
EC_act_total_time2 = zeros(NumTotalTrls,NumECPatches);
EC_act_total_time4 = zeros(NumTotalTrls,NumECPatches);

Trial_label = zeros(NumTotalTrls, 1);   % this is to label phases ans trial types in each phase




