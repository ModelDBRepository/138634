
EC_act= zeros(NumECPatches, NumNodesECPatch);

for i =1: NumECPatches
    for j=1:NumNodesECPatch
        for k=1:NumCortNodes
            EC_act(i,j)= EC_act(i,j) + Cort_act(k)*CortECWts(k,j,i);   % CortECWts is wts entering EC unit k.
        end
    end
end

EC_act = sig(EC_act);
