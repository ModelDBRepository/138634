if(isequal(experiment_type,'CP'))
    t1=1
    t2=1;
    t3=1;
    for k=1: NumTotalTrls %TrlNumTotal %length(Resp_alltrls(:,4))
        if (Trial_label(k,1) == 1)
            Resp_alltrls_Ph1(t1,1)=Resp_alltrls(k,4);
            t1=t1+1;
        elseif(Trial_label(k,1) == 21)
            Resp_alltrls_Ph21(t2,1)=Resp_alltrls(k,4);
            t2=t2+1;
        elseif(Trial_label(k,1) == 22)
            Resp_alltrls_Ph22(t3,1)=Resp_alltrls(k,4);
            t3=t3+1;
        end
    end
    title('Compound Preconditioning','fontsize',12,'fontweight','b');
    hold on
    subplot(1,2,1)
    plot(Resp_alltrls_Ph1,'LineWidth',2);
    axis([1  NumTrls(1) 0.3 0.7])
    %xlabel('Trial Number','fontsize',12,'fontweight','b')
    ylabel('CR','fontsize',12,'fontweight','b')
    title('Phase 1','fontsize',12,'fontweight','b');
    
    subplot(1,2,2)
    plot(Resp_alltrls_Ph21,'LineWidth',2)
    hold on
    plot(Resp_alltrls_Ph22,'LineWidth',2)
    axis([1  NumTrls(2)/2 0.3 0.7])
    %xlabel('Trial Number','fontsize',12,'fontweight','b')
    %ylabel('CR','fontsize',12,'fontweight','b')
    title('Phase 2','fontsize',12,'fontweight','b');
    suptitle ('Compound Preconditioning');
    suplabel ('Trial Number');
elseif(isequal(experiment_type,'Blking'))
    t1=1
    t2=1;
    t3=1;
    
    for k=1: NumTotalTrls %TrlNumTotal %length(Resp_alltrls(:,4))
        if (Trial_label(k,1) == 1)
            Resp_alltrls_Ph1(t1,1)=Resp_alltrls(k,4);
            t1=t1+1;
        elseif(Trial_label(k,1) == 2)
            Resp_alltrls_Ph2(t2,1)=Resp_alltrls(k,4);
            t2=t2+1;
        elseif(Trial_label(k,1) == 3)
            Resp_alltrls_Ph3(t3,1)=Resp_alltrls(k,4);
            t3=t3+1;
        end
    end
    hold on
    subplot(1,3,1)
    plot(Resp_alltrls_Ph1,'LineWidth',2);
    axis([1  NumTrls(1) 0.3 1])
    %xlabel('Trial Number','fontsize',12,'fontweight','b')
    ylabel('CR','fontsize',12,'fontweight','b')
    title('Phase 1','fontsize',12,'fontweight','b');
    
    subplot(1,3,2)
    plot(Resp_alltrls_Ph2,'LineWidth',2)
    hold on
    axis([1  NumTrls(2) 0.3 1])
    %xlabel('Trial Number','fontsize',12,'fontweight','b')
    %ylabel('CR','fontsize',12,'fontweight','b')
    title('Phase 2','fontsize',12,'fontweight','b'); 
    
    subplot(1,3,3)
    plot(Resp_alltrls_Ph3,'LineWidth',2)
    hold on
    axis([1  NumTrls(3) 0.3 1])
    %xlabel('Trial Number','fontsize',12,'fontweight','b')
    %ylabel('CR','fontsize',12,'fontweight','b')
    title('Phase 3','fontsize',12,'fontweight','b');
    suptitle ('Blocking');
    suplabel ('Trial Number');
elseif(isequal(experiment_type,'AE_withZ'))
    t=ones(1,6);       
    for k=1: NumTotalTrls %TrlNumTotal %length(Resp_alltrls(:,4))
        if (Trial_label(k,1) == 11)
            Resp_alltrls_Ph11(t(1),1)=Resp_alltrls(k,4);
            t(1)=t(1)+1;
        elseif(Trial_label(k,1) == 12)
            Resp_alltrls_Ph12(t(2),1)=Resp_alltrls(k,4);
            t(2)=t(2)+1;
        elseif(Trial_label(k,1) == 13)
            Resp_alltrls_Ph13(t(3),1)=Resp_alltrls(k,4);
            t(3)=t(3)+1;
        elseif(Trial_label(k,1) == 2)
            Resp_alltrls_Ph2(t(4),1)=Resp_alltrls(k,4);
            t(4)=t(4)+1;
        elseif(Trial_label(k,1) == 31)   % Y-
            Resp_alltrls_Ph31(t(5),1)=Resp_alltrls(k,4);
            t(5)=t(5)+1;
        elseif(Trial_label(k,1) == 32)   % Z-
            Resp_alltrls_Ph32(t(6),1)=Resp_alltrls(k,4);
            t(6)=t(6)+1;
        end
    end
    %     suptitle ('Acquired Equivalence');
    %     suplabel ('Trial Number'); 
    subplot(1,3,1)
    plot(Resp_alltrls_Ph11,'-.','LineWidth',2);
    axis([1  NumTrls(1)/3 0 1])   %3 is number of trial types in phase 1
    hold on
    plot(Resp_alltrls_Ph12,'--','LineWidth',2);
    plot(Resp_alltrls_Ph13,'LineWidth',2);
    ylabel('CR','fontsize',12,'fontweight','b')
    title('Phase 1','fontsize',12,'fontweight','b');
    legend('AX-','AY-','Z-');
    
    subplot(1,3,2)
    plot(Resp_alltrls_Ph2,'LineWidth',2)
    hold on
    axis([1  NumTrls(2) 0.1 1])
    title('Phase 2','fontsize',12,'fontweight','b'); 
    legend('X+');
    
    subplot(1,3,3)
    plot(Resp_alltrls_Ph31,'-.','LineWidth',2)
    hold on
    axis([1  NumTrls(3)/2 0 0.27])
    plot(Resp_alltrls_Ph32,'LineWidth',2)
    title('Phase 3','fontsize',12,'fontweight','b');
    legend('Y-','Z-');
    
    %     suptitle ('Acquired Equivalence');
    %     suplabel ('Trial Number');   
elseif(isequal(experiment_type,'EzHrd'))
    t=ones (1,4);      
    for k=1: NumTotalTrls %TrlNumTotal %length(Resp_alltrls(:,4))
        if (Trial_label(k,1) == 11)
            Resp_alltrls_Ph11(t(1),1)=Resp_alltrls(k,4);
            t(1)=t(1)+1;
        elseif(Trial_label(k,1) == 12)
            Resp_alltrls_Ph12(t(2),1)=Resp_alltrls(k,4);
            t(2)=t(2)+1;
        elseif(Trial_label(k,1) == 21)
            Resp_alltrls_Ph21(t(3),1)=Resp_alltrls(k,4);
            t(3)=t(3)+1;
        elseif(Trial_label(k,1) == 22)
            Resp_alltrls_Ph22(t(4),1)=Resp_alltrls(k,4);
            t(4)=t(4)+1;    
        end
    end
    hold on
    subplot(1,2,1)
    plot(Resp_alltrls_Ph11,'LineWidth',2);
    axis([1  NumTrls(1)/2 0 1])
    hold on
    plot(Resp_alltrls_Ph12,'LineWidth',2);
    ylabel('CR','fontsize',12,'fontweight','b')
    title('Phase 1','fontsize',12,'fontweight','b');
    
    subplot(1,2,2)
    plot(Resp_alltrls_Ph21,'LineWidth',2)
    hold on
    axis([1  NumTrls(2)/2 0 1])
    plot(Resp_alltrls_Ph22,'LineWidth',2)
    %xlabel('Trial Number','fontsize',12,'fontweight','b')
    %ylabel('CR','fontsize',12,'fontweight','b')
    title('Phase 2','fontsize',12,'fontweight','b'); 
elseif(isequal(experiment_type,'CtxShft'))
    t1=1
    t2=1;
    for k=1: NumTotalTrls %TrlNumTotal %length(Resp_alltrls(:,4))
        if (Trial_label(k,1) == 1)
            Resp_alltrls_Ph1(t1,1)=Resp_alltrls(k,4);
            t1=t1+1;
        elseif(Trial_label(k,1) == 2)
            Resp_alltrls_Ph2(t2,1)=Resp_alltrls(k,4);
            t2=t2+1;
        end
    end
    title('Context Shift','fontsize',12,'fontweight','b');
    hold on
    subplot(1,2,1)
    plot(Resp_alltrls_Ph1,'LineWidth',2);
    axis([1  NumTrls(1) 0.3 0.7])
    %xlabel('Trial Number','fontsize',12,'fontweight','b')
    ylabel('CR','fontsize',12,'fontweight','b')
    title('Phase 1','fontsize',12,'fontweight','b');
    
    subplot(1,2,2)
    plot(Resp_alltrls_Ph2,'LineWidth',2)
    hold on
    axis([1  NumTrls(2) 0.3 0.7])
    %xlabel('Trial Number','fontsize',12,'fontweight','b')
    %ylabel('CR','fontsize',12,'fontweight','b')
    title('Phase 2','fontsize',12,'fontweight','b');
    %     suptitle ('Blocking');
    %     suplabel ('Trial Number');
    
elseif(isequal(experiment_type,'OS2'))
    t1=1
    t2=1;
    t3=1;
    for k=1: NumTotalTrls %TrlNumTotal %length(Resp_alltrls(:,4))
        if (Trial_label(k,1) == 1)
            Resp_alltrls_Ph1(t1,1)=Resp_alltrls(k,4);
            t1=t1+1;
        elseif(Trial_label(k,1) == 21)
            Resp_alltrls_Ph21(t2,1)=Resp_alltrls(k,4);
            t2=t2+1;
        elseif(Trial_label(k,1) == 22)
            Resp_alltrls_Ph22(t3,1)=Resp_alltrls(k,4);
            t3=t3+1;
        end
    end
    title('Overshadowing','fontsize',12,'fontweight','b');
    hold on
    subplot(1,2,1)
    plot(Resp_alltrls_Ph1,'LineWidth',2);
    axis([1  NumTrls(1) 0.3 0.7])
    %xlabel('Trial Number','fontsize',12,'fontweight','b')
    ylabel('CR','fontsize',12,'fontweight','b')
    title('Phase 1','fontsize',12,'fontweight','b');
    
    subplot(1,2,2)
    plot(Resp_alltrls_Ph21,'LineWidth',2)
    hold on
    plot(Resp_alltrls_Ph22,'LineWidth',2)
    axis([1  NumTrls(2)/2 0.4 0.93])
    %xlabel('Trial Number','fontsize',12,'fontweight','b')
    %ylabel('CR','fontsize',12,'fontweight','b')
    title('Phase 2','fontsize',12,'fontweight','b');
    suptitle ('Overshadowing');
    suplabel ('Trial Number');
elseif(isequal(experiment_type,'NegPat'))
    t1=1;
    t2=1;
    t3=1;
    for k=1: NumTotalTrls %TrlNumTotal %length(Resp_alltrls(:,4))
        if (Trial_label(k,1) == 11)
            Resp_alltrls_Ph11(t1,1)=Resp_alltrls(k,4);
            t1=t1+1;
        elseif(Trial_label(k,1) == 12)
            Resp_alltrls_Ph12(t2,1)=Resp_alltrls(k,4);
            t2=t2+1;
        elseif(Trial_label(k,1) == 13)
            Resp_alltrls_Ph13(t3,1)=Resp_alltrls(k,4);
            t3=t3+1;
        end
    end
    title('Negative Patterning','fontsize',12,'fontweight','b');
    hold on
    plot(Resp_alltrls_Ph11,'LineWidth',2);
    %axis([1  NumTrls(1) 0.3 0.8])
    %xlabel('Trial Number','fontsize',12,'fontweight','b')
    ylabel('CR','fontsize',12,'fontweight','b')
      
    plot(Resp_alltrls_Ph12,'LineWidth',2)
    plot(Resp_alltrls_Ph13,'LineWidth',2)
    axis([1  NumTrls(1)/3 0.3 0.8])
    %xlabel('Trial Number','fontsize',12,'fontweight','b')
    %ylabel('CR','fontsize',12,'fontweight','b')
    xlabel ('Trial Number');
elseif(isequal(experiment_type,'NegPatExtra'))
    t1=1;
    t2=1;
    t3=1;
    for k=1: NumTotalTrls %TrlNumTotal %length(Resp_alltrls(:,4))
        if (Trial_label(k,1) == 11)
            Resp_alltrls_Ph11(t1,1)=Resp_alltrls(k,4);
            t1=t1+1;
        elseif(Trial_label(k,1) == 12)
            Resp_alltrls_Ph12(t2,1)=Resp_alltrls(k,4);
            t2=t2+1;
        elseif(Trial_label(k,1) == 13)
            Resp_alltrls_Ph13(t3,1)=Resp_alltrls(k,4);
            t3=t3+1;
        end
    end
    title('Negative Patterning','fontsize',12,'fontweight','b');
    hold on
    plot(Resp_alltrls_Ph11,'LineWidth',2);
    %axis([1  NumTrls(1) 0.3 0.8])
    %xlabel('Trial Number','fontsize',12,'fontweight','b')
    ylabel('CR','fontsize',12,'fontweight','b')
      
    plot(Resp_alltrls_Ph12,'LineWidth',2)
    plot(Resp_alltrls_Ph13,'LineWidth',2)
    axis([1  (NumTrls(1)+ NumTrls(2))/3 0.2 0.85])
    %xlabel('Trial Number','fontsize',12,'fontweight','b')
    %ylabel('CR','fontsize',12,'fontweight','b')
    xlabel ('Trial Number');
end


set(gcf,'Color',[1,1,1])  % this is to make the background color white   

