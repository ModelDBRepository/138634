% shared among all figures

% this can be for figs that donot have different trial types within a phase
plot(Resp_alltrls(:,1),'-.','LineWidth',2)  % ctx
hold on
plot(Resp_alltrls(:,4),'LineWidth',2)   % cue
set(gcf,'Color',[1,1,1])  % this is to make the background color white   

xlabel('Trial Number','fontsize',14,'fontweight','b')
ylabel('CR','fontsize',14,'fontweight','b')
legend('Ctx','Cue');
set(gcf,'Color',[1,1,1])  % this is to make the background color white   

if(isequal(experiment_type,'A+'))
    title('A+','fontsize',14,'fontweight','b');
elseif(isequal(experiment_type,'A-'))
    title('A-','fontsize',14,'fontweight','b');
elseif(isequal(experiment_type,'SP'))
    title('Sensory Preconditioning','fontsize',14,'fontweight','b');
elseif(isequal(experiment_type,'LI'))
    title('Latent Inhibition','fontsize',14,'fontweight','b');
elseif(isequal(experiment_type,'LrIr'))
    title('Learned Irrelevance','fontsize',14,'fontweight','b');
elseif(isequal(experiment_type,'CtxShft'))
    title('Context Shift','fontsize',14,'fontweight','b');
elseif(isequal(experiment_type,'CtxShft_moreTrls'))
    title('Context Shift with Extended Training','fontsize',14,'fontweight','b');    
elseif(isequal(experiment_type,'LI_CtxShft'))
    title('Latent Inhibition Context Shift','fontsize',14,'fontweight','b');
elseif(isequal(experiment_type,'AE_withZ'))
    title('Acquired Equivalence','fontsize',14,'fontweight','b');
elseif(isequal(experiment_type,'Blking'))
    title('Blocking','fontsize',14,'fontweight','b');
elseif(isequal(experiment_type,'CP'))
    title('Compound Preconditioning','fontsize',14,'fontweight','b');
end

%==========================================================================
% this is for phases with diff trl types
if(isequal(experiment_type,'EzHrd')| isequal(experiment_type,'Discrm'))
    t1=1;
    t2=1;
    for TrlNum=1: NumTotalTrls %TrlNumTotal %length(Resp_alltrls(:,4))
        if (mod(TrlNum,2) == 0)
            Resp_alltrls_CS1(t1,1)=Resp_alltrls(TrlNum,4);
            t1=t1+1;
        elseif (mod(TrlNum,2) == 1)
            Resp_alltrls_CS2(t2,1)=Resp_alltrls(TrlNum,4);
            t2=t2+1;
        end
    end

    plot(Resp_alltrls_CS1,'LineWidth',2)
    hold on
    plot(Resp_alltrls_CS2,'LineWidth',2)
    xlabel('Trial Number','fontsize',14,'fontweight','b')
    ylabel('CR','fontsize',14,'fontweight','b')
    title('Easy Hard Transfer','fontsize',14,'fontweight','b');

end
% get second phase data from EzHrd
Resp_alltrls_CS1_ph2 = Resp_alltrls_CS1(NumTrls(1,1)/2 +1 : NumTrls(1,1)/2 + NumTrls(1,2)/2,:);
Resp_alltrls_CS2_ph2 = Resp_alltrls_CS2(NumTrls(1,1)/2 +1 : NumTrls(1,1)/2 + NumTrls(1,2)/2,:);
plot(Resp_alltrls_CS1_ph2,'LineWidth',2)
hold on
plot(Resp_alltrls_CS2_ph2,'LineWidth',2)


    
     
%        
%      elseif (mod(TrlNum,2) == 1)
%          plot(Resp_alltrls(:,4),'LineWidth',4)
%      end
% end


% if(isequal(experiment_type,'CP'))
%     t1=1
%     t2=1;
%     t3=1;
%     for k=1: NumTotalTrls %TrlNumTotal %length(Resp_alltrls(:,4))
%          if (Trial_label(k,1) == 1)
%             Resp_alltrls_Ph1(t1,1)=Resp_alltrls(k,4);
%             t1=t1+1;
%         elseif(Trial_label(k,1) == 21)
%             Resp_alltrls_Ph21(t2,1)=Resp_alltrls(k,4);
%             t2=t2+1;
%         elseif(Trial_label(k,1) == 22)
%             Resp_alltrls_Ph22(t3,1)=Resp_alltrls(k,4);
%             t3=t3+1;
%         end
%     end
% 
%     plot(Resp_alltrls_Ph1,'LineWidth',2)   % cue
%     hold on
%     plot([NumTrls(1)+1 :  NumTrls(1)+ NumTrls(2)/2],Resp_alltrls_Ph21,'LineWidth',2)
% 
%     hold on
%     plot([NumTrls(1)+1 :  NumTrls(1)+ NumTrls(2)/2],Resp_alltrls_Ph22,'LineWidth',2)
%     
%     xlabel('Trial Number','fontsize',14,'fontweight','b')
%     ylabel('CR','fontsize',14,'fontweight','b')
%     title('Compound Preconditioning','fontsize',14,'fontweight','b');
%     legend('Ctx','Cue');
% end






