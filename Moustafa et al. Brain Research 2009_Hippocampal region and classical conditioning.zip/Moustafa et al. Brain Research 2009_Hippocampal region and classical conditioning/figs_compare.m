    

% Comparing B- in SP to normal B-
% 
% %B- in SP (last 50 trials)
% load SP.mat
% plot(Resp_alltrls(151:200,4),'LineWidth',2)   % cue
% hold on
% % B- (just as A-) (first 50 trials).
% load A-.mat
% plot(Resp_alltrls(1:50,4),'LineWidth',2)   % cue
% xlabel('Trial Number','fontsize',12,'fontweight','b')
% ylabel('CR','fontsize',12,'fontweight','b')
% legend('B- in SP','B- alone');
% title('B- with and without SP','fontsize',12,'fontweight','b');
% 
% 
% 
% % Comparing A+ in LI to normal A+
% 
% %A+ in LI (last 100 trials)
% load LI.mat
% plot(Resp_alltrls(101:200,4),'LineWidth',2)   % cue
% hold on
% % A+ (first 100 trials).
% load A+.mat
% plot(Resp_alltrls(1:100,4),'LineWidth',2)   % cue
% xlabel('Trial Number','fontsize',12,'fontweight','b')
% ylabel('CR','fontsize',12,'fontweight','b')
% legend('A+ in LI','A+ alone');
% title('A+ with and without LI','fontsize',12,'fontweight','b');
