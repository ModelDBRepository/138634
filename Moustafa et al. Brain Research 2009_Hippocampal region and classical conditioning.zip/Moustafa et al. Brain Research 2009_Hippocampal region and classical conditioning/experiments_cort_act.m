%   X  Y  A B US
if(isequal(experiment_type,'A+'))
    
    if (ismember(time, CtxX_subtrl))  % context subtrials. to be refined later
        %Cort_act = [1 1 1 0 0 0];
        Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
    elseif (ismember(time, CtxXAUS_subtrl))            % context+A+US subtrials.
        
        %Cort_act = [1 1 1 1 0 1];    % that should change when we talk about delay vs. trace conditioning.
        Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1];
    end
elseif(isequal(experiment_type,'A+Extra'))
    if(PhaseNum == 1)  %A+
        if (ismember(time, CtxX_subtrl))  % context subtrials. to be refined later
            %Cort_act = [1 1 1 0 0 0];
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
        elseif (ismember(time, CtxXAUS_subtrl))            % context+A+US subtrials.
            
            %Cort_act = [1 1 1 1 0 1];    % that should change when we talk about delay vs. trace conditioning.
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1];
        end
    elseif(PhaseNum == 2)  %A-
        if (ismember(time, CtxX_subtrl))  % context subtrials. to be refined later
            %Cort_act = [1 1 1 0 0 0];
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
        elseif (ismember(time, CtxXAUS_subtrl))            % context+A+US subtrials.
            
            %Cort_act = [1 1 1 1 0 1];    % that should change when we talk about delay vs. trace conditioning.
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
        end
    end
    
elseif(isequal(experiment_type,'A-'))
    
    if (ismember(time, CtxX_subtrl))  % context subtrials. to be refined later
        %Cort_act = [1 1 1 0 0 0];
        Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
    elseif (ismember(time, CtxXAUS_subtrl))            % context+A+US subtrials.
        %Cort_act = [1 1 1 1 0 1];    % that should change when we talk about delay vs. trace conditioning.
        Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
        
    end
elseif(isequal(experiment_type,'CtxShft'))  % I think reward is not critical here
    if(PhaseNum == 1)     % A ctx X (Ctx X is the normal context used)
        if (ismember(time, CtxX_subtrl))  % context subtrials. to be refined later
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  1 1 1 1 0 0 0 0  0 0 0 0 0 0 0 0];
            
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
            
        elseif (ismember(time, CtxXAUS_subtrl))
            %Cort_act = [1 1 1 1 0 0];    % that should change when we talk about delay vs. trace conditioning
            
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  1 1 1 1 0 0 0 0  1 1 1 1 1 1 1 1];
            
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0.1 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1];
            
            %Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1];
            
        end
        Trial_label(TrlNumTotal,1) = 1;    % 1 is for phase 1.
    elseif(PhaseNum == 2) % A ctx Y
        if (ismember(time, CtxY_subtrl))  % context subtrials. to be refined later
            Cort_act = [ 0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 1 1 1 1  0 0 0 0 0 0 0 0];
            
            Cort_act = [ 0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
            
        elseif (ismember(time, CtxYAUS_subtrl))
            %Cort_act = [1 1 1 1 0 1];    % that should change when we talk about delay vs. trace conditioning
            
            
            Cort_act = [ 0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1   1 1 1 1 1 1 1 1  0 0 0 0 1 1 1 1  1 1 1 1 1 1 1 1];
            
            %Cort_act = [ 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0   1 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1];
            
            Cort_act = [ 0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1   0.1 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1];
            
            
            %Cort_act = [ 0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1   1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1];
            
        end
        Trial_label(TrlNumTotal,1) = 2;    % 1 is for phase 1.
    end
elseif(isequal(experiment_type,'SP'))
    if(PhaseNum == 1)          % AB-
        if (ismember(time, CtxX_subtrl))  % context subtrials. to be refined later
            %Cort_act = [1 1 1 0 0 0];
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
        elseif (ismember(time, CtxXAB_subtrl))
            %Cort_act = [1 1 1 1 1 0];    % that should change when we talk about delay vs. trace conditioning
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0];
        end
    elseif(PhaseNum == 2)    % A+
        if (ismember(time, CtxX_subtrl))  % context subtrials. to be refined later
            %Cort_act = [1 1 1 0 0 0];
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
        elseif (ismember(time, CtxXAUS_subtrl))
            %Cort_act = [1 1 1 1 0 1];    % that should change when we talk about delay vs. trace conditioning
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1];
        end
    elseif(PhaseNum == 3)  %B- **what about time = 6 here.
        if (ismember(time, CtxX_subtrl))  % context subtrials. to be refined later
            %Cort_act = [1 1 1 0 0 0];
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
        elseif (ismember(time, CtxXB_subtrl))
            %Cort_act = [1 1 1 0 1 0];    % that should change when we talk about delay vs. trace conditioning
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0   0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0];
        end
    end
elseif(isequal(experiment_type,'LI'))
    if(PhaseNum == 1)     % A-
        if (ismember(time, CtxX_subtrl))  % context subtrials. to be refined later
            %Cort_act = [1 1 1 0 0 0];
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
        elseif (ismember(time, CtxXA_subtrl))
            %Cort_act = [1 1 1 1 0 0];    % that should change when we talk about delay vs. trace conditioning
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
        end
    elseif(PhaseNum == 2) % A+
        if (ismember(time, CtxX_subtrl))  % context subtrials. to be refined later
            %Cort_act = [1 1 1 0 0 0];
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
        elseif (ismember(time, CtxXAUS_subtrl))
            %Cort_act = [1 1 1 1 0 1];    % that should change when we talk about delay vs. trace conditioning
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1];
        end
    end
    
elseif(isequal(experiment_type,'LrIr'))
    if(PhaseNum == 1)     % A-
        if (mod(TrlNum,2) == 0)
            if (ismember(time, CtxX_subtrl))  % context subtrials. to be refined later
                %Cort_act = [1 1 1 0 0 0];
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
            elseif (ismember(time, CtxXA_subtrl))
                %Cort_act = [1 1 1 1 0 0];    % that should change when we talk about delay vs. trace conditioning
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
            end
        elseif (mod(TrlNum,2) == 1)  % US-
            if (ismember(time, CtxX_subtrl))  % context subtrials. to be refined later
                %Cort_act = [1 1 1 0 0 0];
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
            elseif (ismember(time, CtxXA_subtrl))
                %Cort_act = [1 1 1 1 0 0];    % that should change when we talk about delay vs. trace conditioning
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
            end
        end
    elseif(PhaseNum == 2) % A+
        if (ismember(time, CtxX_subtrl))  % context subtrials. to be refined later
            %Cort_act = [1 1 1 0 0 0];
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
        elseif (ismember(time, CtxXAUS_subtrl))
            %Cort_act = [1 1 1 1 0 1];    % that should change when we talk about delay vs. trace conditioning
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1];
        end
    end
elseif(isequal(experiment_type,'LrIr2'))
    if(PhaseNum == 1)     % A-
        if (mod(TrlNum,2) == 0)
            if (ismember(time, CtxX_subtrl))  % context subtrials. to be refined later
                %Cort_act = [1 1 1 0 0 0];
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
            elseif (ismember(time, CtxXA_subtrl))
                %Cort_act = [1 1 1 1 0 0];    % that should change when we talk about delay vs. trace conditioning
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
            end
        elseif (mod(TrlNum,2) == 1)  % US-
            if (ismember(time, CtxX_subtrl))  % context subtrials. to be refined later
                %Cort_act = [1 1 1 0 0 0];
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
            elseif (ismember(time, CtxXA_subtrl))
                %Cort_act = [1 1 1 1 0 0];    % that should change when we talk about delay vs. trace conditioning
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1];
            end
        end
    elseif(PhaseNum == 2) % A+
        if (ismember(time, CtxX_subtrl))  % context subtrials. to be refined later
            %Cort_act = [1 1 1 0 0 0];
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
        elseif (ismember(time, CtxXAUS_subtrl))
            %Cort_act = [1 1 1 1 0 1];    % that should change when we talk about delay vs. trace conditioning
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1];
        end
    end
elseif(isequal(experiment_type,'LI_CtxShft'))
    if(PhaseNum == 1)     % A- in ctx X
        if (ismember(time, CtxX_subtrl))  % context subtrials. to be refined later
            %Cort_act = [1 1 1 0 0 0];
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
        elseif (ismember(time, CtxXA_subtrl))
            %Cort_act = [1 1 1 1 0 0];    % that should change when we talk about delay vs. trace conditioning
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
        end
    elseif(PhaseNum == 2) % A+ in ctx Y
        if (ismember(time, CtxY_subtrl))  % context subtrials. to be refined later
            %Cort_act = [1 1 1 0 0 0];
            Cort_act = [ 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
        elseif (ismember(time, CtxYAUS_subtrl))
            %Cort_act = [1 1 1 1 0 1];    % that should change when we talk about delay vs. trace conditioning
            Cort_act = [ 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1   1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1];
        end
    end
    % elseif(isequal(experiment_type,'AE'))
    %     if(PhaseNum == 1)          % AX- and AY- (do shaping and concurrent)
    %         if (mod(TrlNum,2) == 0) % for even numbers, it is AX trials.**do it random
    %             if (ismember(time, CtxX_subtrl))  % AX-
    %                 %Cort_act = [1 1 1 0 0 0];
    %                 Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
    %             elseif (ismember(time, CtxXA_subtrl))
    %                 %Cort_act = [1 1 1 1 1 0];    % that should change when we talk about delay vs. trace conditioning
    %                 Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
    %             end
    %         elseif (mod(TrlNum,2) == 1) % for odd numbers, it is AY trials
    %             if (ismember(time, CtxY_subtrl))  % AY-
    %                 %Cort_act = [1 1 1 0 0 0];
    %                 Cort_act = [ 0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
    %             elseif (ismember(time, CtxYA_subtrl))
    %                 %Cort_act = [1 1 1 1 1 0];    % that should change when we talk about delay vs. trace conditioning
    %                 Cort_act = [0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1   1 1 1 1 1 1 1 1 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
    %             end
    %         end
    %     elseif(PhaseNum == 2)    % X+ (reinforcing in context X)
    %         if (ismember(time, Ctx_subtrl))  % context subtrials. to be refined later
    %             %Cort_act = [1 1 1 0 0 0];
    %             Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
    %         elseif (ismember(time, CtxXUS_subtrl))
    %             %Cort_act = [1 1 1 1 0 1];    % that should change when we talk about delay vs. trace conditioning
    %             Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1];
    %         end
    %     elseif(PhaseNum == 3)  % Y-
    %         if (ismember(time, CtxY_subtrl))  % context subtrials. to be refined later
    %             %Cort_act = [1 1 1 0 0 0];
    %             Cort_act = [0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
    %         elseif (ismember(time, CtxYnoUS_subtrl))   %  ********* change [3 4]
    %             %Cort_act = [1 1 1 0 1 0];    % that should change when we talk about delay vs. trace conditioning
    %             Cort_act = [0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
    %         end
    %     end
elseif(isequal(experiment_type,'AE_withZ'))   % I am for now using B place for context Z
    if(PhaseNum == 1)          % AX- and AY-, and Z- (do shaping and concurrent). I will use cue B place for Z
        if (mod(TrlNum,3) == 0) % for even numbers, it is AX trials.**do it random
            if (ismember(time, CtxX_subtrl))  % AX-
                %Cort_act = [1 1 1 0 0 0];
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
            elseif (ismember(time, CtxXA_subtrl))
                %Cort_act = [1 1 1 1 1 0];    % that should change when we talk about delay vs. trace conditioning
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
            end
            Trial_label(TrlNumTotal,1) = 11; % 11 is for phase 2 AX-
            
        elseif (mod(TrlNum,3) == 1) % for odd numbers, it is AY trials
            if (ismember(time, CtxY_subtrl))  % AY-
                %Cort_act = [1 1 1 0 0 0];
                Cort_act = [ 0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
            elseif (ismember(time, CtxYA_subtrl))
                %Cort_act = [1 1 1 1 1 0];    % that should change when we talk about delay vs. trace conditioning
                Cort_act = [0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1   1 1 1 1 1 1 1 1 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
            end
            Trial_label(TrlNumTotal,1) = 12; % 12 is for phase 2 AY-
        elseif (mod(TrlNum,3) == 2)
            if (ismember(time, CtxY_subtrl)) % Z- (Z here is taking B place; and that is ok)
                Cort_act = [ 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0];
            elseif (ismember(time, CtxYA_subtrl))
                Cort_act = [ 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0];
            end
            Trial_label(TrlNumTotal,1) = 13; % 13 is for phase 2 Z-
        end
    elseif(PhaseNum == 2)    % X+ (reinforcing in context X)
        if (ismember(time, CtxX_subtrl))  % context subtrials. to be refined later
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
        elseif (ismember(time, CtxXUS_subtrl))
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1];
        end
        Trial_label(TrlNumTotal,1) = 2; % X+
    elseif(PhaseNum == 3)  % Y- and Z-
        if (TrlNum  > (NumTrls(1,3)/2))  % Y-
            if (ismember(time, CtxY_subtrl))  % context subtrials. to be refined later
                Cort_act = [0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
            elseif (ismember(time, CtxYnoUS_subtrl))   %  ********* change [3 4]
                Cort_act = [0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
            end
            Trial_label(TrlNumTotal,1) = 31; 
            
        else                               % Z-
            if (ismember(time, CtxY_subtrl))  % context subtrials. to be refined later
                Cort_act = [ 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0];
            elseif (ismember(time, CtxYnoUS_subtrl))   %  ********* change [3 4]
                Cort_act = [ 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0];
            end
            Trial_label(TrlNumTotal,1) = 32; % 11 is for phase 2 AX-
        end
    end
elseif(isequal(experiment_type,'EzHrd'))  % stimuli here share the same units.  I might changes that.
    if(PhaseNum == 1)  % easy pair which is also discrimnation
        if (mod(TrlNum,2) == 0)  % A+
            if (ismember(time, CtxX_subtrl))  % context subtrials. to be refined later
                %Cort_act = [1 1 1 0 0 0];
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
            elseif (ismember(time, CtxXAUS_subtrl))            % context+A+US subtrials.
                
                %Cort_act = [1 1 1 1 0 1];    % that should change when we talk about delay vs. trace conditioning.
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1];
            end
            Trial_label(TrlNumTotal,1) = 11;
        elseif (mod(TrlNum,2) == 1)  % A-
            if (ismember(time, CtxX_subtrl))  % context subtrials. to be refined later
                %Cort_act = [1 1 1 0 0 0];
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
            elseif (ismember(time, CtxXAUS_subtrl))            % context+A+US subtrials.
                
                %Cort_act = [1 1 1 1 0 1];    % that should change when we talk about delay vs. trace conditioning.
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
            end
            Trial_label(TrlNumTotal,1) = 12;
        end
    elseif(PhaseNum == 2)  % hard pair
        if (mod(TrlNum,2) == 0)  % A+
            if (ismember(time, CtxX_subtrl))  % context subtrials. to be refined later
                %Cort_act = [1 1 1 0 0 0];
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
            elseif (ismember(time, CtxXAUS_subtrl))            % context+A+US subtrials.
                
                %Cort_act = [1 1 1 1 0 1];    % that should change when we talk about delay vs. trace conditioning.
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0.6 0.6 0.6 0.6 0.6 0.6 0.6 0.6  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1];
            end
            Trial_label(TrlNumTotal,1) = 21;
        elseif (mod(TrlNum,2) == 1)  % A-
            if (ismember(time, CtxX_subtrl))  % context subtrials. to be refined later
                %Cort_act = [1 1 1 0 0 0];
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
            elseif (ismember(time, CtxXAUS_subtrl))            % context+A+US subtrials.
                
                %Cort_act = [1 1 1 1 0 1];    % that should change when we talk about delay vs. trace conditioning.
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
            end
            Trial_label(TrlNumTotal,1) = 22;
        end
    end
elseif(isequal(experiment_type,'Discrm'))
    if (mod(TrlNum,2) == 0)  % A+
        if (ismember(time, CtxX_subtrl))  % context subtrials. to be refined later
            %Cort_act = [1 1 1 0 0 0];
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
        elseif (ismember(time, CtxXAUS_subtrl))            % context+A+US subtrials.
            
            %Cort_act = [1 1 1 1 0 1];    % that should change when we talk about delay vs. trace conditioning.
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0.6 0.6 0.6 0.6 0.6 0.6 0.6 0.6  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1];
        end
    elseif (mod(TrlNum,2) == 1)  % A-
        if (ismember(time, CtxX_subtrl))  % context subtrials. to be refined later
            %Cort_act = [1 1 1 0 0 0];
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
        elseif (ismember(time, CtxXAUS_subtrl))            % context+A+US subtrials.
            
            %Cort_act = [1 1 1 1 0 1];    % that should change when we talk about delay vs. trace conditioning.
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
        end
    end
elseif(isequal(experiment_type,'Gen'))
    if(PhaseNum == 1)     % A+
        if (ismember(time, CtxX_subtrl))  % context subtrials. to be refined later
            %Cort_act = [1 1 1 0 0 0];
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
        elseif (ismember(time, CtxAUS_subtrl))
            %Cort_act = [1 1 1 1 0 1];    % that should change when we talk about delay vs. trace conditioning
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1];
        end
    elseif(PhaseNum == 2) % A+
        if (ismember(time, CtxX_subtrl))  % context subtrials. to be refined later
            %Cort_act = [1 1 1 0 0 0];
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
        elseif (ismember(time, CtxXAUS_subtrl))
            %Cort_act = [1 1 1 1 0 1];    % that should change when we talk about delay vs. trace conditioning
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0.001  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1];
        end
    end
elseif(isequal(experiment_type,'Blking'))   % I am for now using B place for context Z
    if(PhaseNum == 1)          % A+
        if (ismember(time, CtxX_subtrl))  % context subtrials. to be refined later
            %Cort_act = [1 1 1 0 0 0];
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
        elseif (ismember(time, CtxXAUS_subtrl))            % context+A+US subtrials.
            
            %Cort_act = [1 1 1 1 0 1];    % that should change when we talk about delay vs. trace conditioning.
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1];
        end
        Trial_label(TrlNumTotal,1) = 1;    % 1 is for phase 1.
        
    elseif(PhaseNum == 2)    % AB+
        if (ismember(time, CtxX_subtrl))  % context subtrials. to be refined later
            %Cort_act = [1 1 1 0 0 0];
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
        elseif (ismember(time, CtxXAB_subtrl))
            %Cort_act = [1 1 1 1 1 0];    % that should change when we talk about delay vs. trace conditioning
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  1 1 1 1 1 1 1 1  1 1 1 1 1 1 1 1];
        end
        Trial_label(TrlNumTotal,1) = 2;    % 1 is for phase 1.
        
    elseif(PhaseNum == 3)  % B-
        if (ismember(time, CtxX_subtrl))  % context subtrials. to be refined later
            %Cort_act = [1 1 1 0 0 0];
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
        elseif (ismember(time, CtxXB_subtrl))
            %Cort_act = [1 1 1 0 1 0];    % that should change when we talk about delay vs. trace conditioning
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0   0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0];
        end
        Trial_label(TrlNumTotal,1) = 3;    % 1 is for phase 1.
        
    end
elseif(isequal(experiment_type,'CP'))  % Compound preconditioning
    if(PhaseNum == 1)          % AB-
        if (ismember(time, CtxX_subtrl))  % context subtrials. to be refined later
            %Cort_act = [1 1 1 0 0 0];
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
        elseif (ismember(time, CtxXAB_subtrl))
            %Cort_act = [1 1 1 1 1 0];    % that should change when we talk about delay vs. trace conditioning
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0];
        end
        
        Trial_label(TrlNumTotal,1) = 1;    % 1 is for phase 1.
    elseif(PhaseNum == 2)    % A+ and B-
        if (mod(TrlNum,2) == 0)  %A+
            if (ismember(time, CtxX_subtrl))  % context subtrials. to be refined later
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
            elseif (ismember(time, CtxXAUS_subtrl))
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1];
            end
            Trial_label(TrlNumTotal,1) = 21;    % 21 is for phase 2 A+ trials.
        elseif (mod(TrlNum,2) == 1)  % B-
            if (ismember(time, CtxX_subtrl))  % context subtrials. to be refined later
                %Cort_act = [1 1 1 0 0 0];
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
            elseif (ismember(time, CtxXB_subtrl))
                %Cort_act = [1 1 1 0 1 0];    % that should change when we talk about delay vs. trace conditioning
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0   0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0];
            end
            Trial_label(TrlNumTotal,1) = 22; % 21 is for phase 2 B- trials.
        end
    end
elseif(isequal(experiment_type,'Rev'))  % Reversal
    if(PhaseNum == 1)    % A+ and B-
        if (mod(TrlNum,2) == 0)  %A+
            if (ismember(time, CtxX_subtrl))  % context subtrials. to be refined later
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
            elseif (ismember(time, CtxAUS_subtrl))
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1];
            end
        elseif (mod(TrlNum,2) == 1)  % B-
            if (ismember(time, CtxX_subtrl))  % context subtrials. to be refined later
                %Cort_act = [1 1 1 0 0 0];
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
            elseif (ismember(time, CtxXB_subtrl))
                %Cort_act = [1 1 1 0 1 0];    % that should change when we talk about delay vs. trace conditioning
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0   0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0];
            end
        end
    elseif(PhaseNum == 1) % A- and B+
        if (mod(TrlNum,2) == 0)  %A-
            if (ismember(time, CtxX_subtrl))  % context subtrials. to be refined later
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
            elseif (ismember(time, CtxAUS_subtrl))
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
            end
        elseif (mod(TrlNum,2) == 1)  % B+
            if (ismember(time, CtxX_subtrl))  % context subtrials. to be refined later
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
            elseif (ismember(time, CtxXB_subtrl))
                %Cort_act = [1 1 1 0 1 0];    % that should change when we talk about delay vs. trace conditioning
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0   0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  1 1 1 1 1 1 1 1 ];
            end
        end
        
    end
elseif(isequal(experiment_type,'Rev_A+'))  % Reversal **should be extinction instead
    if(PhaseNum == 1)    % A+
        if (ismember(time, CtxX_subtrl))  % context subtrials. to be refined later
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
        elseif (ismember(time, CtxXAUS_subtrl))
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1];
        end
    elseif(PhaseNum == 2) % A-
        if (ismember(time, CtxX_subtrl))  % context subtrials. to be refined later
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
        elseif (ismember(time, CtxXAUS_subtrl))
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
        end
    end
elseif(isequal(experiment_type,'Rev_B-'))  % Reversal
    if(PhaseNum == 1)    % B-
        if (ismember(time, CtxX_subtrl))  % context subtrials. to be refined later
            %Cort_act = [1 1 1 0 0 0];
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
        elseif (ismember(time, CtxXB_subtrl))
            %Cort_act = [1 1 1 0 1 0];    % that should change when we talk about delay vs. trace conditioning
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0   0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0];
        end
        %      end
    elseif(PhaseNum == 2) % B+
        if (ismember(time, CtxX_subtrl))  % context subtrials. to be refined later
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
        elseif (ismember(time, CtxXB_subtrl))
            %Cort_act = [1 1 1 0 1 0];    % that should change when we talk about delay vs. trace conditioning
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0   0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  1 1 1 1 1 1 1 1 ];
        end
    end
elseif(isequal(experiment_type,'OS'))   % 
    if(PhaseNum == 1)          % AB+
        if (ismember(time, CtxX_subtrl))  %
            %Cort_act = [1 1 1 0 0 0];
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
        elseif (ismember(time, CtxXAUS_subtrl))            % context+A+US subtrials.
            
            %Cort_act = [1 1 1 1 0 1];    % that should change when we talk about delay vs. trace conditioning.
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0.7 0.7 0.7 0.7 0.7 0.7 0.7 0.7  1 1 1 1 1 1 1 1];
        end
        Trial_label(TrlNumTotal,1) = 1;    % 1 is for phase 1.
        
    elseif(PhaseNum == 2)    % B+
        if (ismember(time, CtxX_subtrl))  % context subtrials. to be refined later
            %Cort_act = [1 1 1 0 0 0];
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
        elseif (ismember(time, CtxXAB_subtrl))
            %Cort_act = [1 1 1 1 1 0];    % that should change when we talk about delay vs. trace conditioning
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0   0 0 0 0 0 0 0 0  0.7 0.7 0.7 0.7 0.7 0.7 0.7 0.7  1 1 1 1 1 1 1 1];
        end
        Trial_label(TrlNumTotal,1) = 2;    % 1 is for phase 1.     
    end
    
elseif(isequal(experiment_type,'OS2'))   % 
    if(PhaseNum == 1)          % AB+
        if (ismember(time, CtxX_subtrl))  %
            %Cort_act = [1 1 1 0 0 0];
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
        elseif (ismember(time, CtxXAUS_subtrl))            % context+A+US subtrials.
            
            %Cort_act = [1 1 1 1 0 1];    % that should change when we talk about delay vs. trace conditioning.
            Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0.7 0.7 0.7 0.7 0.7 0.7 0.7 0.7  0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2  1 1 1 1 1 1 1 1];
        end
        Trial_label(TrlNumTotal,1) = 1;    % 1 is for phase 1.
        
    elseif(PhaseNum == 2)   
        if (mod(TrlNum,2) == 0)  % B+
            
            if (ismember(time, CtxX_subtrl))  % context subtrials. to be refined later
                %Cort_act = [1 1 1 0 0 0];
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
            elseif (ismember(time, CtxXAB_subtrl))
                %Cort_act = [1 1 1 1 1 0];    % that should change when we talk about delay vs. trace conditioning
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0   0 0 0 0 0 0 0 0   0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2  1 1 1 1 1 1 1 1];
            end
            Trial_label(TrlNumTotal,1) = 21;    % 1 is for phase 1.   
        elseif (mod(TrlNum,2) == 1)
            
            if (ismember(time, CtxX_subtrl))  % context subtrials. to be refined later
                %Cort_act = [1 1 1 0 0 0];
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
            elseif (ismember(time, CtxXAB_subtrl))
                %Cort_act = [1 1 1 1 1 0];    % that should change when we talk about delay vs. trace conditioning
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0   0.7 0.7 0.7 0.7 0.7 0.7 0.7 0.7 0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1];
            end
            Trial_label(TrlNumTotal,1) = 22;    % 1 is for phase 1.   
        end
    end
elseif(isequal(experiment_type,'NegPat'))   % I am for now using B place for context Z
    if(PhaseNum == 1)          % AX- and AY-, and Z- (do shaping and concurrent). I will use cue B place for Z
        if (mod(TrlNum,3) == 0) % for even numbers, it is AX trials.**do it random
            if (ismember(time, CtxX_subtrl))  % AX+
                %Cort_act = [1 1 1 0 0 0];
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
            elseif (ismember(time, CtxXA_subtrl))
                %Cort_act = [1 1 1 1 1 0];    % that should change when we talk about delay vs. trace conditioning
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1];
            end
            Trial_label(TrlNumTotal,1) = 11; % 11 is for phase 2 AX-
            
        elseif (mod(TrlNum,3) == 1) % for odd numbers, it is AY trials
            if (ismember(time, CtxY_subtrl))  % BX+
                %Cort_act = [1 1 1 0 0 0];
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
            elseif (ismember(time, CtxYA_subtrl))
                %Cort_act = [1 1 1 1 1 0];    % that should change when we talk about delay vs. trace conditioning
                Cort_act = [1 1 1 1 1 1 1 1 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1    1 1 1 1 1 1 1 1];
            end
            Trial_label(TrlNumTotal,1) = 12; % 12 is for phase 2 AY-
        elseif (mod(TrlNum,3) == 2)  %ABX-
            if (ismember(time, CtxX_subtrl)) % Z- (Z here is taking B place; and that is ok)
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0   0 0 0 0 0 0 0 0];
            elseif (ismember(time, CtxXAB_subtrl))
                Cort_act = [ 1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0];
            end
            Trial_label(TrlNumTotal,1) = 13; % 13 is for phase 2 Z-
        end
    end
elseif(isequal(experiment_type,'NegPatExtra'))   % I am for now using B place for context Z
    if(PhaseNum == 1)          % AX- and AY-, and Z- (do shaping and concurrent). I will use cue B place for Z
        if (mod(TrlNum,3) == 0) % for even numbers, it is AX trials.**do it random
            if (ismember(time, CtxX_subtrl))  % AX+
                %Cort_act = [1 1 1 0 0 0];
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
            elseif (ismember(time, CtxXA_subtrl))
                %Cort_act = [1 1 1 1 1 0];    % that should change when we talk about delay vs. trace conditioning
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1];
            end
            Trial_label(TrlNumTotal,1) = 11; % 11 is for phase 2 AX-
            
        elseif (mod(TrlNum,3) == 1) % for odd numbers, it is AY trials
            if (ismember(time, CtxY_subtrl))  % BX+
                %Cort_act = [1 1 1 0 0 0];
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
            elseif (ismember(time, CtxYA_subtrl))
                %Cort_act = [1 1 1 1 1 0];    % that should change when we talk about delay vs. trace conditioning
                Cort_act = [1 1 1 1 1 1 1 1 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1    1 1 1 1 1 1 1 1];
            end
            Trial_label(TrlNumTotal,1) = 12; % 12 is for phase 2 AY-
        elseif (mod(TrlNum,3) == 2)  %ABX-
            if (ismember(time, CtxX_subtrl)) % Z- (Z here is taking B place; and that is ok)
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0   0 0 0 0 0 0 0 0];
            elseif (ismember(time, CtxXAB_subtrl))
                Cort_act = [ 1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0];
            end
            Trial_label(TrlNumTotal,1) = 13; % 13 is for phase 2 Z-
        end
    elseif (PhaseNum == 2)
        if (mod(TrlNum,3) == 0) % for even numbers, it is AX trials.**do it random
            if (ismember(time, CtxX_subtrl))  % AX+
                %Cort_act = [1 1 1 0 0 0];
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
            elseif (ismember(time, CtxXA_subtrl))
                %Cort_act = [1 1 1 1 1 0];    % that should change when we talk about delay vs. trace conditioning
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0.9 0.9 0.9 0.9 0.9 0.9 0.9 0.9];
            end
            Trial_label(TrlNumTotal,1) = 11; % 11 is for phase 2 AX-
            
        elseif (mod(TrlNum,3) == 1) % for odd numbers, it is AY trials
            if (ismember(time, CtxY_subtrl))  % BX+
                %Cort_act = [1 1 1 0 0 0];
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
            elseif (ismember(time, CtxYA_subtrl))
                %Cort_act = [1 1 1 1 1 0];    % that should change when we talk about delay vs. trace conditioning
                Cort_act = [1 1 1 1 1 1 1 1 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1    0.9 0.9 0.9 0.9 0.9 0.9 0.9 0.9];
            end
            Trial_label(TrlNumTotal,1) = 12; % 12 is for phase 2 AY-
        elseif (mod(TrlNum,3) == 2)  %ABX-
            if (ismember(time, CtxX_subtrl)) % Z- (Z here is taking B place; and that is ok)
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0   0 0 0 0 0 0 0 0];
            elseif (ismember(time, CtxXAB_subtrl))
                Cort_act = [ 1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0];
            end
            Trial_label(TrlNumTotal,1) = 13; % 13 is for phase 2 Z-
        end
    end
    
    
elseif(isequal(experiment_type,'PosPat'))   % I am for now using B place for context Z
    if(PhaseNum == 1)          % AX- and AY-, and Z- (do shaping and concurrent). I will use cue B place for Z
        if (mod(TrlNum,3) == 0) % for even numbers, it is AX trials.**do it random
            if (ismember(time, CtxX_subtrl))  % AX-
                %Cort_act = [1 1 1 0 0 0];
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
            elseif (ismember(time, CtxXA_subtrl))
                %Cort_act = [1 1 1 1 1 0];    % that should change when we talk about delay vs. trace conditioning
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
            end
            Trial_label(TrlNumTotal,1) = 11; % 11 is for phase 2 AX-
            
        elseif (mod(TrlNum,3) == 1) % for odd numbers, it is AY trials
            if (ismember(time, CtxY_subtrl))  % BX-
                %Cort_act = [1 1 1 0 0 0];
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0];
            elseif (ismember(time, CtxYA_subtrl))
                %Cort_act = [1 1 1 1 1 0];    % that should change when we talk about delay vs. trace conditioning
                Cort_act = [1 1 1 1 1 1 1 1 0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1   0 0 0 0 0 0 0 0];
            end
            Trial_label(TrlNumTotal,1) = 12; % 12 is for phase 2 AY-
        elseif (mod(TrlNum,3) == 2)  %ABX+
            if (ismember(time, CtxX_subtrl)) % Z- (Z here is taking B place; and that is ok)
                Cort_act = [1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0  0 0 0 0 0 0 0 0   0 0 0 0 0 0 0 0];
            elseif (ismember(time, CtxXAB_subtrl))
                Cort_act = [ 1 1 1 1 1 1 1 1  0 0 0 0 0 0 0 0  1 1 1 1 1 1 1 1  1 1 1 1 1 1 1 1  1 1 1 1 1 1 1 1];
            end
            Trial_label(TrlNumTotal,1) = 13; % 13 is for phase 2 Z-
        end
        
    end
end
